Description
===========
Elements intends to become a library that provides complex form elements for developers to use in their modules.


Elements provided
=================

1. tableselect
2. emailfield
3. searchfield
4. telfield
5. urlfield
6. numberfield
7. rangefield
