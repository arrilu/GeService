// $Id: README.txt,v 1.4 2010/09/27 23:47:40 ericduran Exp $

DESCRIPTION
-----------
This module is a work in progress. We are coordinating the work in the 
Drupal HTML-5 Group at http://groups.drupal.org/html-5. Read our 
Manifesto at http://groups.drupal.org/node/82664.

This module aims to replace all of Drupal's default forms with their 
HTML5 counter-parts. 

You can use this module with any theme, but we recommend taking a look 
at our companion project, HTML Base: http://drupal.org/project/html5_base.


INSTALLATION
------------
This module depends on the Elements module (http://drupal.org/project/elements).


CREDITS
-------