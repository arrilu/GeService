<?php
/**
 * @file mobile-tools-header.tpl.php
 *
 *  Some extra settings for in the <head /> tag specific for mobile
 */  
?>
<meta name = "viewport" content = "user-scalable=no, width=device-width, maximum-scale=1.0" />
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="HandheldFriendly" content="true" />
<link rel="apple-touch-icon" href=""/>
