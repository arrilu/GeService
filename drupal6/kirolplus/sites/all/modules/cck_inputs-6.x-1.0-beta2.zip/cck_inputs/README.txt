 $Id$

CCK Inputs
http://drupal.org/project/cck_inputs

DESCRIPTION:
This is a set of modules, which provide input elements for endusers with the power of cck.

(You can't process data submitted by a webform with these modules. You need another module which handles the submitted data.)


INSTALLATION:
Enable the desired modules and their dependencies.

   
CONFIGURATION:
Add the fields to the content types you want to use them with.
Go to Content - Content Types - choose a content type - Manage Fields


DEPENDENCIES
CCK (at least version 2.1)
Fieldgroup from CCK for "CCK Input Elements - Form Group"


MAINTAINER:
Reservation is maintained by Raimund Hofmann ( http://drupal.org/user/111767 ). 
Please direct all support requests, feature requests, and bug reports to the issue queue: 
http://drupal.org/project/issues/cck_inputs


