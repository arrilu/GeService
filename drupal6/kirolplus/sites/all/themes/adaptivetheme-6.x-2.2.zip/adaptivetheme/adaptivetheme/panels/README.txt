

The Panels directory contains self contained panel layout 
plugins for use with Adaptivetheme. Layouts are inherited
by subthemes so there is no need to copy them over.