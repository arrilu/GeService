// $Id: equalize-columns.js,v 1.1.2.2 2009/12/04 02:41:42 jmburnz Exp $
$(document).ready(function() {
  $('#content-column, .sidebar').equalHeight();
});