
  Adaptivetheme 6.x-2.x is built and supported by http://adaptivethemes.com

  Project page: http://drupal.org/project/adaptivetheme
  Issue queue:  http://drupal.org/project/issues/adaptivetheme

  IMPORTANT :: For basic info and set up guide see: 
  http://adaptivethemes.com/documentation/adaptivetheme-6x-2x

  Adaptivetheme is an advanced starter theme that includes many theme
  settings and layout features.
  
  The core adaptivetheme is not meant to be used, instead copy and paste
  the included subtheme and follow the install instructions in the
  adaptivetheme_subtheme README file.

  If you need to override a template from the core theme, copy and paste it
  into your subtheme so you never hack the core theme.

  Closely review your subthemes .info file, many of the themes features are
  controlled via the info file.
  
  To use all the major features you need to install the following modules 
  (these are not required but to use the advanced features you need them):

  http://drupal.org/project/skinr
  Just install and its ready to use, AT2 has built-in support for the Skinr 
  module and comes pre-packaged with many useful Skinr styles.

  http://drupal.org/project/panels
  Just install and its ready to use, AT2 comes with 9 additional Panels Layouts 
  ready to use - NOTE that to use them you must enable both the Base theme and 
  the Subtheme.

  http://drupal.org/project/block_class
  http://drupal.org/project/blocktheme
  Optionally you can also test out AT2's support for Block class and Blocktheme modules. 
  Again, theres nothing more to do other than installing these module and start 
  using them, AT provides native support out of the box.

