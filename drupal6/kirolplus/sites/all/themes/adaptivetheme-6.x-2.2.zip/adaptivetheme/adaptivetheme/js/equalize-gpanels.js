// $Id: equalize-gpanels.js,v 1.1.2.1 2010/03/26 23:02:16 jmburnz Exp $
$(document).ready(function() {
  $('.gpanel .block-inner').equalHeight();
});